import { Component, OnInit } from '@angular/core';
import { PostService } from './post.service';
import { Post } from './post';
  
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent   {
  name = 'Angular';
  
  posts = new Array<Post>();
    
  constructor(private service:PostService) {}
    
  
  retrieve() {
      this.service.getPosts().subscribe(response => {
          this.posts = response.map(item => 
            {
              return new Post( 
                  item.id,
                  item.name,
                  item.email,
                  item.gender,
                  item.status
              );
            });
        });
  }
}