import { Options } from './options';

import { Component, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
})
export class AppComponent {

  currentItem:string="From app.component";
  selectedOption: Options = new Options(2, 'T-Shirts', 222);

  totalPrice: number = 0;
  options = [
    new Options(1, 'Jeans', 111),
    new Options(2, 'T-Shirts', 222),
    new Options(3, 'Shorts', 333),
    new Options(4, 'Shirts', 444),
    new Options(5, 'Trousers', 555),
    new Options(6, 'Chinos', 666),
    new Options(7, 'Shoes', 777),
  ];

  getValue(optionid: number) {
    this.selectedOption = this.options.filter((item) => item.id == optionid)[0];
    this.options.filter((item) => {
      if (item.id == optionid) {
        this.totalPrice += item.price;
      }
    });
  }
}
